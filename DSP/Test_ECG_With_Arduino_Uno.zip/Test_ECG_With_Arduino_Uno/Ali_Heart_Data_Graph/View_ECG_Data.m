clc,clear,close all
load Ali_Data_Capetured.txt
x=Ali_Data_Capetured';

plot(x)
xlabel('Time');
ylabel('Magnitude');